package dev.md5n.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.md5n.module.Module;
import dev.md5n.module.ModuleManager;
import dev.md5n.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("md5n.json");
    }

    public static void save(ModuleManager manager) {
        JsonObject root = new JsonObject();
        for (Module m : manager.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.getKey());
            JsonObject settings = new JsonObject();
            JsonObject keys = new JsonObject();
            for (Setting s : m.settings()) {
                settings.add(s.name, s.toJson());
                if (s.keyable()) keys.addProperty(s.name, s.getKey());
            }
            o.add("settings", settings);
            o.add("keys", keys);
            root.add(m.name, o);
        }
        try {
            Files.writeString(path(), GSON.toJson(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void load(ModuleManager manager) {
        Path p = path();
        if (!Files.exists(p)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
            for (Module m : manager.all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.setKey(o.get("key").getAsInt());
                if (o.has("settings")) {
                    JsonObject settings = o.getAsJsonObject("settings");
                    for (Setting s : m.settings()) {
                        if (!settings.has(s.name)) continue;
                        try {
                            s.fromJson(settings.get(s.name));
                        } catch (Exception ignored) {
                        }
                    }
                }
                if (o.has("keys")) {
                    JsonObject keys = o.getAsJsonObject("keys");
                    for (Setting s : m.settings()) {
                        if (s.keyable() && keys.has(s.name)) s.setKey(keys.get(s.name).getAsInt());
                    }
                }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
