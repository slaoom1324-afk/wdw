package dev.md5n.module;

import dev.md5n.module.modules.AimAssist;
import dev.md5n.module.modules.Ambiance;
import dev.md5n.module.modules.ElytraAssist;
import dev.md5n.module.modules.ElytraTarget;
import dev.md5n.module.modules.Flight;
import dev.md5n.module.modules.Fullbright;
import dev.md5n.module.modules.HitBox;
import dev.md5n.module.modules.Hud;
import dev.md5n.module.modules.KillAura;
import dev.md5n.module.modules.KillVfx;
import dev.md5n.module.modules.PlayerAlert;
import dev.md5n.module.modules.Sky;
import dev.md5n.module.modules.Sprint;
import dev.md5n.module.modules.ThemeSettings;
import dev.md5n.module.modules.TriggerBot;
import dev.md5n.setting.Setting;
import dev.md5n.util.Sfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // أضف مودك الجديد هنا
        add(new AimAssist());
        add(new TriggerBot());
        add(new KillAura());
        add(new HitBox());

        add(new Sprint());
        add(new Flight());
        add(new ElytraAssist());
        add(new ElytraTarget());

        add(new Hud());
        add(new Fullbright());
        add(new PlayerAlert());

        add(new Sky());
        add(new KillVfx());
        add(new Ambiance());

        add(new ThemeSettings());

        get(Hud.class).setEnabled(true);
    }

    private void add(Module m) { modules.add(m); }

    public List<Module> all() { return Collections.unmodifiableList(modules); }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (m.getClass() == type) return (T) m;
        return null;
    }

    /** مفاتيح المودات + مفاتيح الخيارات (فقط وأنت داخل اللعبة بدون قوائم). */
    public void pollKeys() {
        long window = MinecraftClient.getInstance().getWindow().getHandle();
        for (Module m : modules) {
            if (m.getKey() >= 0) {
                boolean down = InputUtil.isKeyPressed(window, m.getKey());
                if (down && !m.keyDown) m.toggle();
                m.keyDown = down;
            }
            for (Setting s : m.settings()) {
                if (!s.keyable() || s.getKey() < 0) continue;
                boolean down = InputUtil.isKeyPressed(window, s.getKey());
                if (down && !s.isKeyDown()) {
                    s.onKey();
                    Sfx.click();
                }
                s.setKeyDown(down);
            }
        }
    }

    public void onTick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    public void onHudRender(DrawContext ctx, RenderTickCounter tickCounter) {
        for (Module m : modules) if (m.isEnabled()) m.onHudRender(ctx);
    }
}
