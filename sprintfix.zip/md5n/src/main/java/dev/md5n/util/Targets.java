package dev.md5n.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

public final class Targets {
    private Targets() {}

    public static boolean valid(Entity e, boolean players, boolean hostile, boolean passive) {
        if (!(e instanceof LivingEntity living)) return false;
        if (e == MinecraftClient.getInstance().player) return false;
        if (!living.isAlive() || living.isSpectator()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return players;
        if (e instanceof Monster) return hostile;
        return passive;
    }
}
