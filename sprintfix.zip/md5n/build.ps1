$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$tools = Join-Path $root ".tools"
New-Item -ItemType Directory -Force -Path $tools | Out-Null

# ---- JDK 21 ----
$jdkDir = Get-ChildItem $tools -Directory -Filter "jdk-21*" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $jdkDir) {
    Write-Host "[1/3] Downloading JDK 21 (one time only)..."
    $zip = Join-Path $tools "jdk.zip"
    Invoke-WebRequest -UseBasicParsing -Uri "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse" -OutFile $zip
    Expand-Archive -Path $zip -DestinationPath $tools -Force
    Remove-Item $zip
    $jdkDir = Get-ChildItem $tools -Directory -Filter "jdk-21*" | Select-Object -First 1
}
$env:JAVA_HOME = $jdkDir.FullName
$env:Path = "$($env:JAVA_HOME)\bin;$($env:Path)"

# ---- Gradle 8.12 ----
$gradleDir = Join-Path $tools "gradle-9.2.1"
if (-not (Test-Path $gradleDir)) {
    Write-Host "[2/3] Downloading Gradle 8.12 (one time only)..."
    $zip = Join-Path $tools "gradle.zip"
    Invoke-WebRequest -UseBasicParsing -Uri "https://services.gradle.org/distributions/gradle-9.2.1-bin.zip" -OutFile $zip
    Expand-Archive -Path $zip -DestinationPath $tools -Force
    Remove-Item $zip
}

# ---- Build ----
Write-Host "[3/3] Building md5n (first run takes several minutes)..."
& (Join-Path $gradleDir "bin\gradle.bat") build --no-daemon
if ($LASTEXITCODE -ne 0) { throw "Build failed. Copy the error above and send it." }

$jar = Get-ChildItem (Join-Path $root "build\libs") -Filter "md5n-*.jar" |
    Where-Object { $_.Name -notlike "*-sources.jar" } | Select-Object -First 1
Copy-Item $jar.FullName -Destination $root -Force

Write-Host ""
Write-Host "DONE: $($jar.Name) is in this folder. Put it in your mods folder."
Start-Process explorer.exe $root
